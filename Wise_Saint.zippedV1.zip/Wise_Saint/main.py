# This file is for strategy

from util.objects import *
from util.routines import *
from util.tools import find_hits


class Bot(BotCommandAgent):
    # This function runs every in-game tick (every time the game updates anything)
    def run(self):
        if self.intent is not None:
            return
        d2=abs(self.me.location.y-self.foe_goal.location.y)
        d1=abs(self.ball.location.y-self.foe_goal.location.y)
        is_in_front_ball = (d1-d2)>0
        if self.kickoff_flag:
        # set_intent tells the bot what it's trying to do
            self.set_intent(kickoff())
            return
        # retreat = self.ball.location.y - 250
        retreat_location = Vector3((self.ball.location.x, self.ball.location.y - 250, 0))

        if is_in_front_ball:
            self.set_intent(goto(retreat_location))
            return
        self.set_intent(short_shot(self.foe_goal.location))
        targets = {
            #needs 2 values that are two locations on field
            'at_opponent_goal':(self.foe_goal.left_post,self.foe_goal.right_post),
            'away_from_our_net':(self.friend_goal.right_post, self.friend_goal.left_post)
        }
        hits = find_hits(self,targets)
        if len(hits['at_opponent_goal'])>0:
            self.set_intent(hits['at_opponent_goal'][0])
            return
        if len(hits['away_from_our_net'])>0:
            self.set_intent(hits['away_from_our_net'][0])
            return
        
        if self.ball.location.y < -3870:
            self.set_intent(atba)
            self.set_intent(short_shot(self.foe_goal))

        ball_location = self.ball.location
        my_car = self.me.location
        my_car_x = self.me.location.x
        my_car_y = self.me.location.y
        target_location = Vector3(self.ball.location.y + 100 and self.ball.location.x -100,0)
        in_top_left_space_friendly = None
        in_top_left_space_friendly_x = my_car_x < 2045
        in_top_left_space_friendly_y = my_car_y > 1230 
        #and my_car_y < -2460
        if in_top_left_space_friendly_x == True and in_top_left_space_friendly_y == True:
           in_top_left_space_friendly = True
        #bottom_left_space_friendly_x = my_car_location.x < (-2045,-1230,0)
        close_enough_LF = (ball_location - my_car).magnitude() <= 250
        if in_top_left_space_friendly == True and close_enough_LF == True:
            self.set_intent(goto(target_location))
            self.set_intent(short_shot(self.foe_goal.location))
            return
        
        if self.me.location.z > 55:
            self.set_intent(recovery)
            return
        if self.me.boost > 90:
            self.set_intent(short_shot(self.foe_goal.location))
            return
        available_boosts = [boost for boost in self.boosts if boost.active]
        closest_boost = None
        closest_distance = 10000
        for boost in available_boosts:
            distance = (self.me.location - boost.location).magnitude()
            if closest_boost is None or distance < closest_distance:
                clostest_boost = boost
        if closest_boost is not None:
            self.set_intent(goto(closest_boost.location))
            return
        if len(available_boosts) > 0 and self.time/5 % 0:
            self.set_intent(goto(available_boosts[0].location))
            return
        out_bounds_left = self.ball.location.y > 5050 and self.ball.location.x > 893 and self.ball.location.z > 620
        out_bounds_right = self.ball.location.y > 5050 and self.ball.location.x < -893 and self.ball.location.z > 620
        if out_bounds_left == True and out_bounds_right == True:
            self.set_intent(short_shot(0,3500,0))
            return